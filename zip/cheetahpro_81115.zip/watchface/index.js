﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_linear_scale_pointer_img = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 18;
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 18;
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_pl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 193,
              y: 48,
              week_en: ["day_pl_00.png","day_pl_01.png","day_pl_02.png","day_pl_03.png","day_pl_04.png","day_pl_05.png","day_pl_06.png"],
              week_tc: ["day_pl_00.png","day_pl_01.png","day_pl_02.png","day_pl_03.png","day_pl_04.png","day_pl_05.png","day_pl_06.png"],
              week_sc: ["day_pl_00.png","day_pl_01.png","day_pl_02.png","day_pl_03.png","day_pl_04.png","day_pl_05.png","day_pl_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 193,
              month_startY: 24,
              month_sc_array: ["mth_pl_01.png","mth_pl_02.png","mth_pl_03.png","mth_pl_04.png","mth_pl_05.png","mth_pl_06.png","mth_pl_07.png","mth_pl_08.png","mth_pl_09.png","mth_pl_10.png","mth_pl_11.png","mth_pl_12.png"],
              month_tc_array: ["mth_pl_01.png","mth_pl_02.png","mth_pl_03.png","mth_pl_04.png","mth_pl_05.png","mth_pl_06.png","mth_pl_07.png","mth_pl_08.png","mth_pl_09.png","mth_pl_10.png","mth_pl_11.png","mth_pl_12.png"],
              month_en_array: ["mth_pl_01.png","mth_pl_02.png","mth_pl_03.png","mth_pl_04.png","mth_pl_05.png","mth_pl_06.png","mth_pl_07.png","mth_pl_08.png","mth_pl_09.png","mth_pl_10.png","mth_pl_11.png","mth_pl_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 126,
              day_startY: 25,
              day_sc_array: ["dt_00.png","dt_01.png","dt_02.png","dt_03.png","dt_04.png","dt_05.png","dt_06.png","dt_07.png","dt_08.png","dt_09.png"],
              day_tc_array: ["dt_00.png","dt_01.png","dt_02.png","dt_03.png","dt_04.png","dt_05.png","dt_06.png","dt_07.png","dt_08.png","dt_09.png"],
              day_en_array: ["dt_00.png","dt_01.png","dt_02.png","dt_03.png","dt_04.png","dt_05.png","dt_06.png","dt_07.png","dt_08.png","dt_09.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 293,
              src: 'bt_on.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 141,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 325,
              y: 89,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_heart_rate_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 403,
              // start_y: 328,
              // color: 0xFFF80707,
              // pointer: 'point_bpm.png',
              // lenght: -222,
              // line_width: 14,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 450,
              // y: 327,
              // font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: 90,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'sm_00.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'sm_01.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'sm_02.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'sm_03.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'sm_04.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'sm_05.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'sm_06.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'sm_07.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'sm_08.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'sm_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 450,
                center_y: 327,
                pos_x: 450,
                pos_y: 327,
                angle: 90,
                src: 'sm_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 64,
              // start_y: 328,
              // color: 0xFFFC5403,
              // pointer: 'point_steps.png',
              // lenght: -222,
              // line_width: 14,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 30,
              // y: 327,
              // font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'sm_00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'sm_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'sm_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'sm_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'sm_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'sm_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'sm_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'sm_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'sm_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'sm_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 30,
                center_y: 327,
                pos_x: 30,
                pos_y: 327,
                angle: -90,
                src: 'sm_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 125,
              // start_y: 394,
              // color: 0xFF01E4FE,
              // pointer: 'point_batt.png',
              // lenght: 220,
              // line_width: 14,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 418,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'sm_proc.png',
              unit_tc: 'sm_proc.png',
              unit_en: 'sm_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 102,
              hour_startY: 73,
              hour_array: ["d_00.png","d_01.png","d_02.png","d_03.png","d_04.png","d_05.png","d_06.png","d_07.png","d_08.png","d_09.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 102,
              minute_startY: 223,
              minute_array: ["d2_00.png","d2_01.png","d2_02.png","d2_03.png","d2_04.png","d2_05.png","d2_06.png","d2_07.png","d2_08.png","d2_09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 305,
              second_startY: 221,
              second_array: ["m_00.png","m_01.png","m_02.png","m_03.png","m_04.png","m_05.png","m_06.png","m_07.png","m_08.png","m_09.png"],
              second_zero: 1,
              second_space: -8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 193,
              y: 48,
              week_en: ["day_pl_00.png","day_pl_01.png","day_pl_02.png","day_pl_03.png","day_pl_04.png","day_pl_05.png","day_pl_06.png"],
              week_tc: ["day_pl_00.png","day_pl_01.png","day_pl_02.png","day_pl_03.png","day_pl_04.png","day_pl_05.png","day_pl_06.png"],
              week_sc: ["day_pl_00.png","day_pl_01.png","day_pl_02.png","day_pl_03.png","day_pl_04.png","day_pl_05.png","day_pl_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 293,
              src: 'bt_on.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 141,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 418,
              font_array: ["sm_00.png","sm_01.png","sm_02.png","sm_03.png","sm_04.png","sm_05.png","sm_06.png","sm_07.png","sm_08.png","sm_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'sm_proc.png',
              unit_tc: 'sm_proc.png',
              unit_en: 'sm_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 102,
              hour_startY: 73,
              hour_array: ["d_00.png","d_01.png","d_02.png","d_03.png","d_04.png","d_05.png","d_06.png","d_07.png","d_08.png","d_09.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 102,
              minute_startY: 223,
              minute_array: ["d2_00.png","d2_01.png","d2_02.png","d2_03.png","d2_04.png","d2_05.png","d2_06.png","d2_07.png","d2_08.png","d2_09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth WYŁ,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth WŁ,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth WYŁ"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth WŁ"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 316,
              y: 234,
              w: 72,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 322,
              y: 141,
              w: 60,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 322,
              y: 75,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 394,
              y: 100,
              w: 60,
              h: 230,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 28,
              y: 100,
              w: 60,
              h: 230,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 127,
              y: 20,
              w: 180,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function text_update() {
              console.log('text_update()');

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 3 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 450 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 30 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 403;
                  let start_y_normal_heart_rate = 328;
                  let lenght_ls_normal_heart_rate = -222;
                  let line_width_ls_normal_heart_rate = 14;
                  let color_ls_normal_heart_rate = 0xFFF80707;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    line_width_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_y_normal_heart_rate_draw = start_y_normal_heart_rate_draw - line_width_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    radius: 7,
                    color: color_ls_normal_heart_rate,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_heart_rate = 15;
                  let pointer_offset_y_ls_normal_heart_rate = 15;
                  normal_heart_rate_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw + line_width_ls_normal_heart_rate / 2 - pointer_offset_x_ls_normal_heart_rate,
                    y: start_y_normal_heart_rate + lenght_ls_normal_heart_rate - pointer_offset_y_ls_normal_heart_rate,
                    src: 'point_bpm.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 64;
                  let start_y_normal_step = 328;
                  let lenght_ls_normal_step = -222;
                  let line_width_ls_normal_step = 14;
                  let color_ls_normal_step = 0xFFFC5403;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    radius: 7,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 15;
                  let pointer_offset_y_ls_normal_step = 15;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step + lenght_ls_normal_step - pointer_offset_y_ls_normal_step,
                    src: 'point_steps.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 125;
                  let start_y_normal_battery = 394;
                  let lenght_ls_normal_battery = 220;
                  let line_width_ls_normal_battery = 14;
                  let color_ls_normal_battery = 0xFF01E4FE;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 7,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 15;
                  let pointer_offset_y_ls_normal_battery = 15;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery + lenght_ls_normal_battery - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_y_ls_normal_battery,
                    src: 'point_batt.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}