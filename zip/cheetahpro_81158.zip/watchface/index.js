﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_step_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'nomos_tangente_nolancette_480.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 332,
              y: 215,
              image_array: ["09_forecast_01.png","09_forecast_02.png","09_forecast_03.png","09_forecast_04.png","09_forecast_05.png","09_forecast_06.png","09_forecast_07.png","09_forecast_08.png","09_forecast_09.png","09_forecast_10.png","09_forecast_11.png","09_forecast_12.png","09_forecast_13.png","09_forecast_14.png","09_forecast_15.png","09_forecast_16.png","09_forecast_17.png","09_forecast_18.png","09_forecast_19.png","09_forecast_20.png","09_forecast_21.png","09_forecast_22.png","09_forecast_23.png","09_forecast_24.png","09_forecast_25.png","09_forecast_26.png","09_forecast_27.png","09_forecast_28.png","09_forecast_29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 229,
              font_array: ["verde_00.png","verde_01.png","verde_02.png","verde_03.png","verde_04.png","verde_05.png","verde_06.png","verde_07.png","verde_08.png","verde_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'verde_percento.png',
              unit_tc: 'verde_percento.png',
              unit_en: 'verde_percento.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 411,
              src: 'datario.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'nomos_tangente_passi.png',
              center_x: 240,
              center_y: 339,
              x: 8,
              y: 63,
              start_angle: 0,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 359,
              font_array: ["blu_00.png","blu_01.png","blu_02.png","blu_03.png","blu_04.png","blu_05.png","blu_06.png","blu_07.png","blu_08.png","blu_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 226,
              day_startY: 420,
              day_sc_array: ["blu_00.png","blu_01.png","blu_02.png","blu_03.png","blu_04.png","blu_05.png","blu_06.png","blu_07.png","blu_08.png","blu_09.png"],
              day_tc_array: ["blu_00.png","blu_01.png","blu_02.png","blu_03.png","blu_04.png","blu_05.png","blu_06.png","blu_07.png","blu_08.png","blu_09.png"],
              day_en_array: ["blu_00.png","blu_01.png","blu_02.png","blu_03.png","blu_04.png","blu_05.png","blu_06.png","blu_07.png","blu_08.png","blu_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'nomos_tangente_ore_new.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 3,
              hour_posY: 133,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'nomo_tangente_minuti_new.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 3,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'nomos_tangente_centro.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 16,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 287,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 212,
              w: 50,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}