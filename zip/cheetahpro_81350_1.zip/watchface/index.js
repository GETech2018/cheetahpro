﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_distance_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 362,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 393,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_14n.png","w_1n.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 362,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Sist_13.png',
              unit_tc: 'Nr.Sist_13.png',
              unit_en: 'Nr.Sist_13.png',
              imperial_unit_sc: 'Nr.Sist_13.png',
              imperial_unit_tc: 'Nr.Sist_13.png',
              imperial_unit_en: 'Nr.Sist_13.png',
              negative_image: 'Nr.Sist_10.png',
              invalid_image: 'Nr.Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 190,
                y: 362,
                font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Nr.Sist_13.png',
                unit_tc: 'Nr.Sist_13.png',
                unit_en: 'Nr.Sist_13.png',
                imperial_unit_sc: 'Nr.Sist_13.png',
                imperial_unit_tc: 'Nr.Sist_13.png',
                imperial_unit_en: 'Nr.Sist_13.png',
                negative_image: 'Nr.Sist_10.png',
                invalid_image: 'Nr.Sist_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 362,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 111,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 111,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 203,
              y: 138,
              week_en: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              week_tc: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              week_sc: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 203,
              month_startY: 99,
              month_sc_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_6.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_tc_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_6.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_en_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_6.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 30,
              day_sc_array: ["Nr. Secondi_00.png","Nr. Secondi_01.png","Nr. Secondi_02.png","Nr. Secondi_03.png","Nr. Secondi_04.png","Nr. Secondi_05.png","Nr. Secondi_06.png","Nr. Secondi_07.png","Nr. Secondi_08.png","Nr. Secondi_09.png"],
              day_tc_array: ["Nr. Secondi_00.png","Nr. Secondi_01.png","Nr. Secondi_02.png","Nr. Secondi_03.png","Nr. Secondi_04.png","Nr. Secondi_05.png","Nr. Secondi_06.png","Nr. Secondi_07.png","Nr. Secondi_08.png","Nr. Secondi_09.png"],
              day_en_array: ["Nr. Secondi_00.png","Nr. Secondi_01.png","Nr. Secondi_02.png","Nr. Secondi_03.png","Nr. Secondi_04.png","Nr. Secondi_05.png","Nr. Secondi_06.png","Nr. Secondi_07.png","Nr. Secondi_08.png","Nr. Secondi_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 416,
              y: 152,
              src: 'LOCK.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 318,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 409,
              y: 319,
              src: 'OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 41,
              y: 151,
              src: 'AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 374,
              am_y: 198,
              am_sc_path: 'AM_00.png',
              am_en_path: 'AM_00.png',
              pm_x: 374,
              pm_y: 198,
              pm_sc_path: 'PM_00.png',
              pm_en_path: 'PM_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 31,
              hour_startY: 191,
              hour_array: ["Nr. Ore_00.png","Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 205,
              minute_startY: 191,
              minute_array: ["Nr. Ore_00.png","Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 358,
              second_startY: 247,
              second_array: ["Nr. Secondi_00.png","Nr. Secondi_01.png","Nr. Secondi_02.png","Nr. Secondi_03.png","Nr. Secondi_04.png","Nr. Secondi_05.png","Nr. Secondi_06.png","Nr. Secondi_07.png","Nr. Secondi_08.png","Nr. Secondi_09.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 191,
              src: 'Nr. Ore_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Secondi.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 48,
              second_posY: 242,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 362,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 393,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_14n.png","w_1n.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 362,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Nr.Sist_13.png',
              unit_tc: 'Nr.Sist_13.png',
              unit_en: 'Nr.Sist_13.png',
              imperial_unit_sc: 'Nr.Sist_13.png',
              imperial_unit_tc: 'Nr.Sist_13.png',
              imperial_unit_en: 'Nr.Sist_13.png',
              negative_image: 'Nr.Sist_10.png',
              invalid_image: 'Nr.Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 190,
                y: 362,
                font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Nr.Sist_13.png',
                unit_tc: 'Nr.Sist_13.png',
                unit_en: 'Nr.Sist_13.png',
                imperial_unit_sc: 'Nr.Sist_13.png',
                imperial_unit_tc: 'Nr.Sist_13.png',
                imperial_unit_en: 'Nr.Sist_13.png',
                negative_image: 'Nr.Sist_10.png',
                invalid_image: 'Nr.Sist_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 362,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Sist_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 309,
              y: 111,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 111,
              font_array: ["Nr.Sist_00.png","Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 203,
              y: 138,
              week_en: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              week_tc: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              week_sc: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 203,
              month_startY: 99,
              month_sc_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_6.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_tc_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_6.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_en_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_6.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 196,
              day_startY: 30,
              day_sc_array: ["Nr. Secondi_00.png","Nr. Secondi_01.png","Nr. Secondi_02.png","Nr. Secondi_03.png","Nr. Secondi_04.png","Nr. Secondi_05.png","Nr. Secondi_06.png","Nr. Secondi_07.png","Nr. Secondi_08.png","Nr. Secondi_09.png"],
              day_tc_array: ["Nr. Secondi_00.png","Nr. Secondi_01.png","Nr. Secondi_02.png","Nr. Secondi_03.png","Nr. Secondi_04.png","Nr. Secondi_05.png","Nr. Secondi_06.png","Nr. Secondi_07.png","Nr. Secondi_08.png","Nr. Secondi_09.png"],
              day_en_array: ["Nr. Secondi_00.png","Nr. Secondi_01.png","Nr. Secondi_02.png","Nr. Secondi_03.png","Nr. Secondi_04.png","Nr. Secondi_05.png","Nr. Secondi_06.png","Nr. Secondi_07.png","Nr. Secondi_08.png","Nr. Secondi_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 416,
              y: 152,
              src: 'LOCK.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 49,
              y: 318,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 409,
              y: 319,
              src: 'OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 41,
              y: 151,
              src: 'AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 374,
              am_y: 198,
              am_sc_path: 'AM_00.png',
              am_en_path: 'AM_00.png',
              pm_x: 374,
              pm_y: 198,
              pm_sc_path: 'PM_00.png',
              pm_en_path: 'PM_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 31,
              hour_startY: 191,
              hour_array: ["Nr. Ore_00.png","Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 205,
              minute_startY: 191,
              minute_array: ["Nr. Ore_00.png","Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 191,
              src: 'Nr. Ore_10.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 49,
              w: 100,
              h: 125,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 334,
              w: 100,
              h: 111,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 294,
              y: 49,
              w: 100,
              h: 125,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 334,
              w: 100,
              h: 113,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 355,
              y: 244,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 184,
              w: 100,
              h: 130,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 139,
              w: 82,
              h: 123,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}